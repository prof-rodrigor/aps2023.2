[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/D2W4hp7u)
**Universidade Federal da Paraíba - UFPB** \
**Centro de Ciências Exatas e Educação - CCAE** \
**Departamento de Ciências Exatas - DCX**

**Professor:** [Rodrigo Rebouças de Almeida](http://rodrigor.dcx.ufpb.br)

# Atividade

Implemente as classes especificadas no diagrama abaixo, de modo que os testes passem.

Observe que o diagrama não especifica os atributos das classes. Você tem liberdade para implementar os atributos que julgar necessários.

![diagrama](diagrama.png)
