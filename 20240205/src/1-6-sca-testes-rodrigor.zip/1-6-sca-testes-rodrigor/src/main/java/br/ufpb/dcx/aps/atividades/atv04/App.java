package br.ufpb.dcx.aps.atividades.atv04;

public class App {

    public static void main(String[] argsadd){
        System.out.println("Alo Mundo");

    }
}
