package br.ufpb.dcx.aps.atividades.atv04;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Disciplina {

    private String codigo, nome;
    private Curso curso;

    private static final int CAPACIDADE_INICIAL_TURMAS = 15;

    private List<Turma> turmas = new ArrayList<>(CAPACIDADE_INICIAL_TURMAS);

    public Disciplina(Curso curso, String codigo, String nome) {
        this.curso = curso;
        this.codigo = codigo;
        this.nome = nome;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Curso getCurso() {
        return this.curso;
    }

    public Turma getTurma(int codigo) {
        if(codigo <= 0)
            throw new IllegalArgumentException("código inválido:"+codigo);
        if(codigo > turmas.size())
            throw new IllegalArgumentException("Não existe turma com código:"+codigo);
        return this.turmas.get(codigo-1);
    }

    public List<Turma> getTurmas() {
        return this.turmas;
    }

    public Turma criarTurma() {
        Turma novaTurma = new Turma(turmas.size()+1, this);
        this.turmas.add(novaTurma);
        return novaTurma;
    }
}
