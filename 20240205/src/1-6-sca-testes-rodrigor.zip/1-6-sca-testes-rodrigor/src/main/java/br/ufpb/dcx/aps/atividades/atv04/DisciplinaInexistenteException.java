package br.ufpb.dcx.aps.atividades.atv04;

public class DisciplinaInexistenteException extends RuntimeException{

    public DisciplinaInexistenteException(String message) {
        super(message);
    }
}
