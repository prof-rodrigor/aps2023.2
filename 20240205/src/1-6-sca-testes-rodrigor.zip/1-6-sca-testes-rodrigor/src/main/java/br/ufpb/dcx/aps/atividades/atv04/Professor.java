package br.ufpb.dcx.aps.atividades.atv04;

public class Professor {

    private String siape, nome;

    public Professor(String siape, String nome) {
        if(siape == null || siape.isEmpty())
            throw new IllegalArgumentException("siape invalido:"+siape);
        this.siape = siape;
        this.nome = nome;
    }


    public Professor(String siape) {
        this(siape,"");
    }

    public String getSiape() {
        return siape;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
