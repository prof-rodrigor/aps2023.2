package br.ufpb.dcx.aps.atividades.atv04;

public class AlunoInexistenteException extends RuntimeException{

    public AlunoInexistenteException(String message) {
        super(message);
    }
}
