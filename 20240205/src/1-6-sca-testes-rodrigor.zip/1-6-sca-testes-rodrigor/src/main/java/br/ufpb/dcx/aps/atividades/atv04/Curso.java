package br.ufpb.dcx.aps.atividades.atv04;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.*;

public class Curso {

    private String nome;
    private Map<String,Disciplina> disciplinaMap = new HashMap<>();

    private Map<String, Aluno> alunos = new LinkedHashMap<>();


    public Curso(String nome) {
        this.nome = nome;
    }

    public Curso() {
        this.nome = "";
    }

    public void matricular(Aluno aluno) {
        if(aluno == null)
            throw new IllegalArgumentException("aluno inválido:null");
        if(this.alunos.containsKey(aluno.getMatricula()))
            throw new AlunoJaExistenteException("aluno já matriculado:"+aluno.getMatricula());
        this.alunos.put(aluno.getMatricula(), aluno);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Disciplina criarDisciplina(String codigo, String nome) {
        Disciplina nova = new Disciplina(this,codigo,nome);
        this.disciplinaMap.put(nova.getCodigo(),nova);
        return nova;
    }

    public Disciplina getDisciplina(String codigo){
        if(!this.disciplinaMap.containsKey(codigo))
            throw new DisciplinaInexistenteException("Não existe disciplina com código:"+codigo);
        return disciplinaMap.get(codigo);
    }

    public Collection<Aluno> getAlunosMatriculados() {
        return this.alunos.values();
    }

    public boolean isMatriculado(String matricula) {
        return this.alunos.containsKey(matricula);
    }
}
