package br.ufpb.dcx.aps.atividades.atv04;

public class AlunoJaExistenteException extends RuntimeException{

    public AlunoJaExistenteException(String message) {
        super(message);
    }
}
