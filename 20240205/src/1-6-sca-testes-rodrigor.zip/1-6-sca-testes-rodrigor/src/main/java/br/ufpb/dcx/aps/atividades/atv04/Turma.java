package br.ufpb.dcx.aps.atividades.atv04;

import java.util.LinkedHashMap;
import java.util.Map;

public class Turma {

    private int codigo;
    private Professor professor;

    private Disciplina disciplina;

    private Map<String,Aluno> matriculados = new LinkedHashMap<>();

    public Turma(int codigo, Disciplina disciplina) {
        this.codigo = codigo;
        this.disciplina = disciplina;
    }


    public int getCodigo() {
        return this.codigo;
    }

    public void setProfessor(Professor professor) {
        this.professor = professor;
    }

    public Professor getProfessor() {
        return this.professor;
    }

    public void addAluno(Aluno aluno) {
        if(!this.disciplina.getCurso().isMatriculado(aluno.getMatricula()))
            throw new AlunoInexistenteException("Aluno não está matriculado no curso:"+this.disciplina.getCurso().getNome());
        this.matriculados.put(aluno.getMatricula(),aluno);


    }
}
